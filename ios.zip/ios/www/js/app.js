// Ionic Starter App

// angular.module is a global place for creating, registering and retrieving Angular modules
// 'starter' is the name of this angular module example (also set in a <body> attribute in index.html)
// the 2nd parameter is an array of 'requires'
// 'starter.services' is found in services.js
// 'starter.controllers' is found in controllers.js
var genie =angular.module('genieApp', ['ionic','ngCookies','pubnub.angular.service','azure-mobile-service.module','auth0','angular-storage','angular-jwt'])

genie.run(function($ionicPlatform) {
  $ionicPlatform.ready(function() {
    // Hide the accessory bar by default (remove this to show the accessory bar above the keyboard
    // for form inputs)
    if (window.cordova && window.cordova.plugins && window.cordova.plugins.Keyboard) {
      cordova.plugins.Keyboard.hideKeyboardAccessoryBar(true);
    }
    if (window.StatusBar) {
      // org.apache.cordova.statusbar required
      StatusBar.styleLightContent();
    }
  });
})

genie.config(function($stateProvider, $urlRouterProvider,authProvider, $httpProvider, jwtInterceptorProvider) {

	
	//console.log(AmazonLoginServiceProvider)
	//AmazonLoginServiceProvider.setClientId('amzn1.application-oa2-client.3d1bc32e86a947c68bb12f7e99d67735');


  // Ionic uses AngularUI Router which uses the concept of states
  // Learn more here: https://github.com/angular-ui/ui-router
  // Set up the various states which the app can be in.
  // Each state's controller can be found in controllers.js
  $stateProvider

// setup an abstract state for the tabs directive
  /*.state('auth', {
  	url: "/auth",
  	abstract: true,
  	templateUrl: "templates/auth.html"
	})
    .state('auth.login', {
    	url: "/login",
	    views: {
	      "auth-login": {
	        templateUrl: "templates/auth-login.html",
	        controller:"AuthenticationCtrl"
	      }
	    }
  	})*/
	  
	  //Auth0
	  .state('login', {
	      url: '/login',
	      templateUrl: 'templates/login.html',
	      controller: 'AuthenticationCtrl',
	    })
	  
  // setup an abstract state for the tabs directive
    .state('tasks', {
	
    url: "/tasks",
    abstract: true,
    templateUrl: "templates/tasks.html"
		,data: {
		      // This tells Auth0 that this state requires the user to be logged in.
		      // If the user isn't logged in and he tries to access this state
		      // he'll be redirected to the login page
		      requiresLogin: true
		    }
  })

  // Each tab has its own nav history stack:

  .state('tasks.completed', {
	  	resolve: {getTasks:function(TasksService){return TasksService.getTasks()}},
    url: '/completed',
    views: {
      'tasks-completed': {
        templateUrl: 'templates/tasks-completed.html'
        ,controller: 'TasksCtrl'
      }
    }
	,data: {
	      // This tells Auth0 that this state requires the user to be logged in.
	      // If the user isn't logged in and he tries to access this state
	      // he'll be redirected to the login page
	      requiresLogin: true
	    }
  })
  .state('tasks.completed-detail', {
		   	resolve: {getTasks:function(TasksService,$stateParams){console.log($stateParams.currentId); return TasksService.getTaskChat($stateParams.currentId)}},
      url: '/completed/:currentId',
    views: {
      'tasks-completed': {
        templateUrl: 'templates/tasks-current-detail.html'
        ,controller: 'TaskChatCtrl'
      }
    }
  })
  .state('tasks.current', {
	  	resolve: {getTasks:function(TasksService){return TasksService.getTasks()}},
      url: '/current',
      views: {
        'tasks-current': {
          templateUrl: 'templates/tasks-current.html'
          ,controller: 'TasksCtrl'
        }
      }
	,data: {
	      // This tells Auth0 that this state requires the user to be logged in.
	      // If the user isn't logged in and he tries to access this state
	      // he'll be redirected to the login page
	      requiresLogin: true
	    }
	  //,resolve:{
	//	  authorize: function(AuthorizationService){ return AuthorizationService.isAuthenticated();  }
	  //}
	  //,resolve:{authenticated:[ function(AuthorizationFactory){return AuthorizationFactory.getToken();  }]}
    })
    .state('tasks.current-detail', {
		   	resolve: {getTasks:function(TasksService,$stateParams){console.log($stateParams.currentId); return TasksService.getTaskChat($stateParams.currentId)}},
      url: '/current/:currentId',
      views: {
        'tasks-current': {
          templateUrl: 'templates/tasks-current-detail.html'
          ,controller: 'TaskChatCtrl'
        }
      }
	,data: {
	      // This tells Auth0 that this state requires the user to be logged in.
	      // If the user isn't logged in and he tries to access this state
	      // he'll be redirected to the login page
	      requiresLogin: true
	    }
    })
  	.state('tasks.account', {
    url: '/account',
    views: {
      'tasks-account': {
        templateUrl: 'templates/tasks-account.html'
        //,controller: 'AccountCtrl'
      }
    }
	,data: {
	      // This tells Auth0 that this state requires the user to be logged in.
	      // If the user isn't logged in and he tries to access this state
	      // he'll be redirected to the login page
	      requiresLogin: true
	    }
  });

  // if none of the above states are matched, use this as the fallback
  $urlRouterProvider.otherwise('/tasks/current');
  
  authProvider.init({
     domain: 'subant05.auth0.com',
     clientID: 'eiipuf7MwZjdjdHPvznsPZKTszW68o5y',
     loginState: 'login'
   });
   
   jwtInterceptorProvider.tokenGetter = function(store, jwtHelper, auth) {
       var idToken = store.get('token');
       var refreshToken = store.get('refreshToken');
       // If no token return null
       if (!idToken || !refreshToken) {
         return null;
       }
       // If token is expired, get a new one
       if (jwtHelper.isTokenExpired(idToken)) {
         return auth.refreshIdToken(refreshToken).then(function(idToken) {
           store.set('token', idToken);
           return idToken;
         });
       } else {
         return idToken;
       }
     }

     $httpProvider.interceptors.push('jwtInterceptor');

});
genie.constant("REST_API", { 
                                     "login": "/genie_api/users/login",
                                     "logout": "/genie_api/users/logout",
                                     "isauthenticated":"/genie_api/users/isauthenticated"
                                }
);
genie.run(function($rootScope, auth, store, jwtHelper, $location) {
	
	
  // This hooks all auth events to check everything as soon as the app starts
  auth.hookEvents();
  var refreshingToken = null;
  $rootScope.$on('$locationChangeStart', function() {
    var token = store.get('token');
    var refreshToken = store.get('refreshToken');
    if (token) {
      if (!jwtHelper.isTokenExpired(token)) {
        if (!auth.isAuthenticated) {
          auth.authenticate(store.get('profile'), token);
        }
      } else {
        if (refreshToken) {
          if (refreshingToken === null) {
              refreshingToken =  auth.refreshIdToken(refreshToken).then(function(idToken) {
                store.set('token', idToken);
                auth.authenticate(store.get('profile'), idToken);
              }).finally(function() {
                  refreshingToken = null;
              });
          }
          return refreshingToken;
        } else {
          $location.path('/login');
        }
      }
    }

  });
});
genie.constant('AzureMobileServiceClient', {
    API_URL : 'https://geniezappos.azure-mobile.net/',
    API_KEY : 'aApCBTYqoadcTTVVEzkJQXpgFZoElA55',
  });
genie.constant('PubNubCredentials', {
   subscribe_key: 'sub-c-e9ac07d8-fe54-11e4-aa11-02ee2ddab7fe',
   publish_key: 'pub-c-66771adc-1179-48ca-b325-2620506b2bd7',
   secret_key: 'sec-c-ODk2MWUzZTktNWMwZC00NmI3LWFiYWQtNTMwYjIxOTY1Y2Yx',
      channels:{
               newtasks:'genienewtaskschannel',
               completedtasks: 'geniecompletedtaskschannel',
               deletedtasks:'geniedeletedtaskschannel'
            }
   //auth_key: $rootScope.authKey,
   //uuid: $rootScope.data.uuid,
   //ssl: true
 });
/*genie.run(function($rootScope, $state, AuthorizationService) {
	
	

	
	
	
	///ROUTE CHANGE EVENT - START 
    $rootScope.$on("$stateChangeStart", function(event, toState, toParams, fromState, fromParams){ 
      // AuthorizationService.isAuthenticated()
   });
});*/
