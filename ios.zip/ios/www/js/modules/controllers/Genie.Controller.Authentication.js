var Genie;
(function(Genie){
	(function(Controller){
		
		Controller.Authentication = (function(){
							
											function Authentication($scope,store,$location,auth,$state,AuthorizationService){
												this.$scope = $scope;
												this.$location = $location;
												this.store = store;
												this.auth = auth;
												this.$state =$state;
												this.AuthorizationService = AuthorizationService;
												$scope.Authentication = this;
												if(!this.store.inMemoryCache.profile && !this.store.inMemoryCache.token){
													this.login();
												}
											    
				
											}
											
											Authentication.prototype.login = function(){
												var that = this;
											    this.auth.signin({
											      authParams: {
											        scope: 'openid offline_access',
											        device: 'Mobile device'
											      }
											    }, function(profile, token, accessToken, state, refreshToken) {
											      // Success callback
													
													that.AuthorizationService.setupUser(profile,token, accessToken, state, refreshToken)
														.then(function(data){
	  											      		that.$state.go('tasks.current');
														})
													
											      
											    }, function() {
											      // Error callback
											    });
												
												
											}
											Authentication.prototype.logout = function() {
												var that = this;
												this.AuthorizationService.logout().then(function(){
  	  											  that.$state.go("login")
  	  											  that.login();
												})
	  											  
											}
											
											
											
											
											
											return Authentication;
			
							})()
		
	})(Genie.Controller || (Genie.Controller = {}) )
	
})(Genie || (Genie = {}));
genie.controller('AuthenticationCtrl',['$scope','store','$location','auth','$state', 'AuthorizationService',Genie.Controller.Authentication]);