var Genie;
(function(Genie){
	(function(Controller){
		
		Controller.Tasks = (function(){
							
											function Tasks($scope,$timeout,$ionicPopup,$filter,TasksService,PubNub,PubNubCredentials){
												this.$scope = $scope;
												this.$timeout = $timeout;
												this.TasksService = TasksService;
												this.$ionicPopup = $ionicPopup;
												this.$filter = $filter;
												this.PubNub = PubNub;
												this.PubNub.init({
														        publish_key: PubNubCredentials.publish_key,
														        subscribe_key: PubNubCredentials.subscribe_key,
																secret_key:PubNubCredentials.secret_key
														    });
												this.channels = PubNubCredentials.channels;
												this.getTasks();
												this.watches()											
												$scope.Tasks = this;
												
											    
				
											}
											
											Tasks.prototype.watches = function(){
												var that = this;
											    this.$scope.$watch('Tasks.TasksService.Tasks', function(newVal) {
													that.getTasks();
											     });
												
											}
											
											Tasks.prototype.getTasks = function(){
												/*var that = this;
												this.TasksService.getTasks().then(function(data){
													that.tasks = data
												});*/
												
												this.tasks = this.TasksService.Tasks
												
												/*this.activeTasks = this.$filter('filter')(this.TasksService.Tasks,{active:true,complete:false},function(actual, expected) {
													 return angular.equals(actual, expected)
												})
												this.completedTasks = this.$filter('filter')(this.TasksService.Tasks,{active:true,complete:true},function(actual, expected) {
													 return angular.equals(actual, expected)
												})*/
											}
											
											Tasks.prototype.refreshTasks = function(){
												var that = this;
												this.TasksService.getTasks().then(function(tasks){
													that.tasks = tasks;	
													that.$scope.$broadcast('scroll.refreshComplete');
												});
											}
											
											Tasks.prototype.deleteTask = function(task){
												//console.log("Controller Delete:",task)
												var that = this;
												this.$ionicPopup.confirm({
													     title: 'Alert',
													     template: 'Are you sure you want delete this task?'
													   }).then(function(res) {
													     if(res) {
													       that.TasksService.deleteTask(task).then(function(data){
															   that.PubNub.ngPublish({
																		    channel: that.channels.deletedtasks,
																		    message: 'deletedtasks'
																		  });
														   });
														   
													     } else {
													       
													     }
											   	  		});
												
											}
											
											Tasks.prototype.markAsCompleteTask = function(task){
												var that = this;
												this.$ionicPopup.confirm({
													     title: 'Alert',
													     template: 'Are you sure you want mark this task as complete?'
													   }).then(function(res) {
													     if(res) {
													       that.TasksService.markAsCompleteTask(task).then(function(data){
															   that.PubNub.ngPublish({
																		    channel: that.channels.completedtasks,
																		    message: 'completedtasks'
																		  });
														   });
														   
													     } else {
													       
													     }
											   	  		});
												
											}
											 // A confirm dialog
											
											
											return Tasks;
			
							})()
		
	})(Genie.Controller || (Genie.Controller = {}) )
	
})(Genie || (Genie = {}));
genie.controller('TasksCtrl',['$scope','$timeout','$ionicPopup','$filter','TasksService','PubNub','PubNubCredentials', Genie.Controller.Tasks]);