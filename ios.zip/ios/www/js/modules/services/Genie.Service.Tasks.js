var Genie;
(function(Genie){	
	
	(function(Service){
		
		Service.Tasks = (function(){

											function Tasks($q,$ionicLoading,TasksFactory,AuthorizationService){
												this.$q= $q;
												this.TasksFactory = TasksFactory;
												this.AuthorizationService = AuthorizationService;
												this.Tasks=[];
												this.$ionicLoading =$ionicLoading;
												this.getTasks();
												this.taskChat;
												
											};
											
											Tasks.prototype.loaderShow = function(){
												this.$ionicLoading.show({
													template:'Loading...'
												});
											};		
											Tasks.prototype.loaderHide = function(){
												this.$ionicLoading.hide();
											};
											Tasks.prototype.getTasks = function(){
												this.loaderShow();
												var deferred = this.$q.defer();
												var that =this;
												this.TasksFactory.getTasks(this.AuthorizationService.getUser())
													.then(function(data){
														that.setTasks(data)
														that.loaderHide();
														deferred.resolve(that.Tasks)
												});
												return deferred.promise;
											}
											
											
											Tasks.prototype.setTasks = function(data){
												 this.Tasks = data;
											}
											Tasks.prototype.addTask = function(task) {
												//this.loaderShow();
												var deferred = this.$q.defer();
												var that = this;
												  this.TasksFactory.addTask(task,this.AuthorizationService.getUser()).then(function(){
													  						var data= {inserted:true,error:""};	
																			 // that.loaderHide();																		
													  						deferred.resolve(data);
												  					},function(err){
																			var data= {inserted:false,error:err};
																			//that.loaderHide();
												  							deferred.rejected(data);
												  					});
												  
												  return deferred.promise;
												  //console.log(this.Tasks);
											 };
												  
 											 
 											 Tasks.prototype.deleteTask = function(obj) {
												  //this.loaderShow();
	   												var deferred = this.$q.defer();
	   												var that =this;
	  												 this.TasksFactory.deleteTask(obj)
	  													 .then(function(){
	  												 		 var data= {deleted:true,error:""};	
	  														 that.getTasks().then(function(){
																  // that.loaderHide();
	  														 	deferred.resolve(data);
	  														 });
	  													 },function(error){
	  												 		 var data= {deleted:false,error:error};	
																 that.loaderHide();
	  														 deferred.rejected(data);
	  													 });
	  												 return deferred.promise;
 											 };
												
										    
										     Tasks.prototype.markAsCompleteTask = function(obj) {
												// this.loaderShow();
 												var deferred = this.$q.defer();
 												var that =this;
												 this.TasksFactory.markAsCompleteTask(obj)
													 .then(function(){
												 		 var data= {updated:true,error:""};	
														 that.getTasks().then(function(){
															//  that.loaderHide();
														 	deferred.resolve(data);
														 })
													 },function(error){
												 		 var data= {updated:false,error:error};	
														  // that.loaderHide();
														 deferred.rejected(data);
													 });
												 return deferred.promise;
										    };
											
											Tasks.prototype.getTaskChat = function(id){
												//this.loaderShow();
												var deferred = this.$q.defer();
												var that =this;
												this.TasksFactory.getTaskChat(id,this.AuthorizationService.getUser())
													.then(function(response){
														
														var data ={}
														if(!Boolean(data)){
															data.data =response;
															data.isEmpty = true;
															data.error=undefined;
															that.taskChat = response;
															that.taskChat[0].conversation=[];
															//that.loaderHide();
															deferred.resolve(that.taskChat);
															
														}else{
															data.data =response;
															data.isEmpty = false;
															data.error=undefined;
															that.taskChat = response;				
															that.TasksFactory.getChatHistory(response[0].id)
																.then(function(conv){
																			that.taskChat[0].conversation = conv;
																			//that.loaderHide();
																			deferred.resolve(that.taskChat);
																		},
																		function(err){
																			//that.loaderHide();
																			deferred.reject(err);
																		})
														}
														
														
														
													},function(err){
														var data ={}
														data.error=err;
														alert(err);
														//that.loaderHide();
														deferred.reject(data);
													}
												);
												return deferred.promise;
											}
											
											Tasks.prototype.insertMessage = function(message){
												return this.TasksFactory.insertMessage(message);
											}
												
											return Tasks;
									})();
									
									
			
	})(Genie.Service || (Genie.Service={}))


})(Genie || (Genie ={}))
genie.service('TasksService',['$q','$ionicLoading','TasksFactory','AuthorizationService', Genie.Service.Tasks]);