var Genie;
(function(Genie){	
	
	(function(Factory){
		
		Factory.Tasks = (function(){

											function Tasks($q,Azureservice){
																
												var methods = {};
												
												methods.getTasks =function(user){
												 return Azureservice.query('Tasks', {
												    criteria: {
												            user_id:user.id,
															user_client_id : user.clientID													
															
												        },
															orderBy: [
															            {
															                column:'modifiedAt',
															                direction:'desc'
															            }
															        ]
												    });
												   /* .then(function(items) {
												        // Assigin the results to a $scope variable 
												        $scope.items = items;

												    }, function(err) {
												        console.error('There was an error quering Azure ' + err);
												    });*/
												};
												
												methods.addTask =  function(name,user) {	
														
	   												 return Azureservice.insert('Tasks', {
														 				user_id: user.id,
														 				user_email: user.email,
														 				user_name: user.name,
														 				user_client_id: user.clientID,
														 				chat_channel: "genie"+ user.id + name + new Date().valueOf().toString(),
														 				title:name, 
														 				active:true,
																		complete:false,
																		assigned:false});	
											 	};
												
												methods.deleteTask = function(obj) {
													return Azureservice.update('Tasks', {
													        id: obj.id,
													        active: false,
															_deleted: true
													    })
 											      
 											 	};
												methods.markAsCompleteTask = function(obj) {
													return Azureservice.update('Tasks', {
													        id: obj.id,
													        complete: true
													    })
													    /*.then(function() {
													        console.log('Update successful');
													    }, function(err) {
													        console.error('Azure Error: ' + err);
													    });	*/									      
 											 	};
												
												methods.getTaskChat = function(id,user){
												// var deferred =	$q.defer()
   												 return Azureservice.query('Tasks', {
   												    criteria: {
												            user_id:user.id,
															user_client_id : user.clientID,
   															id : id	
   												        }
   												    });
													
												}
												
												methods.insertMessage = function(message){
   												 		return Azureservice.insert('Chats', message);	
												};
												
												methods.getChatHistory = function(chat_id){
													return Azureservice.query('Chats', {
													    criteria: {
													           chat_id: chat_id			
													        }
													        
													    })
												};
												
												
												return methods
												
												
											};
											
											
											return Tasks;
									})();
									
									
			
	})(Genie.Factory || (Genie.Factory={}))


})(Genie || (Genie ={}))
genie.factory('TasksFactory',['$q','Azureservice', Genie.Factory.Tasks]);