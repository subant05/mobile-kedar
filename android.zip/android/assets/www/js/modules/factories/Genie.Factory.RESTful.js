var Genie;
(function(Genie){
    (function(Factory){
		
		Factory.RESTful = (function(){
				 			
								function RESTful($http,$q,Azureservice){
								    var showLoader = function() {document.getElementById('loader').style.display="block";}
                                    var hideLoader = function() {document.getElementById('loader').style.display="none";}
									var RESTapi ={}
										 		RESTapi.get =function(url){
													console.log("get")
																 var httpProperties ={    method: "GET",
												                                           url: url,
												                                           cache:false
																						   //,headers:{} // Could use this...but not necessary
												                                       }
											                    var that = this;
											                    var deferred = $q.defer();
                                                                showLoader();
																$http(httpProperties).success(function (response, status) {
											                                                    deferred.resolve(response);
                                                                                                hideLoader();
											
											                                            }).error(function (response, status) {
																						   deferred.reject("An error occured while fetching items");
                                                                                            hideLoader();
											                                            });
														       return deferred.promise;										 
									 			};
                                                
                                                RESTapi.post = function(url,data){
																 var httpProperties ={    method: "POST",
												                                           url: url,
												                                           cache:false
																						   //,headers:{} // Could use this...but not necessary
												                                       }
                                                                 if(data){
                                                                    httpProperties.data = data;
                                                                 }
											                    var that = this;
											                    var deferred = $q.defer();
                                                                showLoader();
																$http(httpProperties).success(function (response, status) {
											                                                    deferred.resolve(response);
                                                                                                hideLoader();
											
											                                            }).error(function (response, status) {
																						   deferred.reject("An error occured while fetching items");
                                                                                            hideLoader();
											                                            });
														       return deferred.promise;										 
									 			}
                                        
                                                RESTapi.delete = function(url,data){
                                                                var httpProperties ={    method: "DELETE",
												                                           url: url,
												                                           cache:false
																						   ,headers:data
												                                       }
                                                                
											                    var that = this;
											                    var deferred = $q.defer();
                                                                showLoader();
																$http(httpProperties).success(function (response, status) {
											                                                    deferred.resolve(response);
                                                                                                hideLoader();
											
											                                            }).error(function (response, status) {
																						   deferred.reject("An error occured while fetching items");
                                                                                            hideLoader();
											                                            });
														       return deferred.promise;	
                                                
                                                
                                                };
												
												RESTapi.selectUser = function(data){
													 return Azureservice.query('Users', {
													    criteria: {
													            email:data.email
																//,name: data.name,
																//user_id: data.username,
																//picture: data.picture,
																//created_at:data.created_at,
																,clientID: data.clientID
																//,global_client_id:data.global_client_id,
																//identities_access_token:data.identities.access_token,
																//identities_connection:data.identities.connection,
																//identities_isSocial:data.identities.isSocial
															
																
													        }
													    });
													   /* .then(function(items) {
													        // Assigin the results to a $scope variable 
													        $scope.items = items;

													    }, function(err) {
													        console.error('There was an error quering Azure ' + err);
													    });*/
													
												};
												
												RESTapi.insertUser = function(data){
												 return Azureservice.insert('Users', {
												    
												            email:data.email,
															name: data.name,
															user_id: data.username,
															picture: data.picture,
															created_at:data.created_at,
															clientID: data.clientID,
															global_client_id:data.global_client_id,
															identities_access_token:data.identities.access_token,
															identities_connection:data.identities.connection,
															identities_isSocial:data.identities.isSocial
														
															
												        
												    });
													/*.then(function() { 
													        console.log('Insert successful');
													    }, function(err) {
													        console.error('Azure Error: ' + err);
													    });*/
												};
												
												RESTapi.setupUser = function(data){
													var deferred = $q.defer();
													var that = this;
													// Does User Exist....
													this.selectUser(data).then(function(user){
														//console.log("Users Found...",user)
														if(!Boolean(user.length)){
															//User Doesn't Exist...Lets Add User
															//console.log("Insert...")
															that.insertUser(data).then(function(){
								
																//Return The New User Info
																deferred.resolve(data);
															},
															//Unable to Add User
									   					 	function(err) {
									   								        console.error('Azure Error - Inser User: ' + err);
									   										deferred.reject(err)
									   							}
															)
														}else{
															//console.log("User Found...")
															// User Exists...Lets Return their Info
															deferred.resolve(user[0]);
														}
													},
													//Unable to Select A User
													 function(err) {
																        console.error('Azure Error - Query User: ' + err);
																		deferred.reject(err)
																    });
													return deferred.promise
												}
								   return RESTapi;
                            	}
								return RESTful;
							})();
							
							
    
    })(Genie.Factory || (Genie.Factory={}))
	
})(Genie||(Genie={}))
	
genie.factory("RESTfulFactory",['$http','$q','Azureservice',Genie.Factory.RESTful])