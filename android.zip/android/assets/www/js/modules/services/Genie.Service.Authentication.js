var Genie;
(function(Genie){
    (function(Service){
        
        var Authorization = (function(){
            
            function Authorization($http,$q,$state,REST_URLS,$cookieStore,RESTfulFactory,store,$location,auth){
                this.$inject = ['$http', '$q', '$state', 'REST_URLS','$cookieStore','store','$location','auth'];
                this.$q = $q;
                this.$http = $http;
                this.$state = $state;
                this.REST_URLS = REST_URLS;
                this.$cookieStore = $cookieStore;
				this.RESTfulFactory = RESTfulFactory;
				this.store = store;
				this.$location = $location;
				this.auth = auth;
				

            }


                

                Authorization.prototype.logout = function(){
					var that = this;
					return this.$q.all(function(resolve, reject, notify) {
  					  that.auth.signout();
  					  that.store.remove('profile');
  					  that.store.remove('token');
					});
                }
				
				Authorization.prototype.setupUser = function(profile,token, accessToken, state, refreshToken){
					var deferred = this.$q.defer();
					var that = this;
					this.RESTfulFactory.setupUser(profile).then(function(resp){
						that.setUser(resp);
						//console.log(that.User,resp);
				      	that.store.set('profile', profile);
				      	that.store.set('token', token);
				      	that.store.set('refreshToken', refreshToken);
				      	deferred.resolve(resp);
						
					});
					return deferred.promise;					
					
				}
				Authorization.prototype.isUserLoggedIn = function(){
					if(!this.store.inMemoryCache.profile && !this.store.inMemoryCache.token){
						this.login();
					}
				}
				
				Authorization.prototype.getUser = function(){
					return this.store.get("User");
				}
				
				Authorization.prototype.setUser = function(user){
					this.store.set("User",user);
				}
				
				


            return Authorization;

        })();

        Service.Authorization  = Authorization;



    })(Genie.Service || (Genie.Service = {} )) // Passing Arguments to Auto Function. If Genie.Service doesn't exist, then we create and assign as argument

    var Service = Genie.Service; // Passing newly created service object to local property.
     
})(Genie || (Genie= {} )) // Passing Arguments to Auto Function. If Genie doesn't exist, then we create and assign as argument



//Angular Registration
genie.service("AuthorizationService",['$http', '$q', '$state', 'REST_API','$cookieStore','RESTfulFactory','store','$location','auth',Genie.Service.Authorization]);
