var Genie;
(function(Genie){
	(function(Controller){
		
		Controller.TaskChat = (function(){
							
											function TaskChat($scope,$timeout,$stateParams,TasksService,PubNub,$rootScope,PubNubCredentials){
												this.$scope = $scope;
												this.$timeout = $timeout;
												this.TasksService = TasksService;
												this.$rootScope = $rootScope;
												this.PubNub = PubNub;
												this.$stateParams = $stateParams;
												this.chat={};
												var id = $stateParams.currentId;			
												this.PubNub.init({
														        publish_key: PubNubCredentials.publish_key,
														        subscribe_key: PubNubCredentials.subscribe_key,
																secret_key:PubNubCredentials.secret_key
														    });
												this.getTaskChat(id);
												$scope.TaskChat = this;
											    
				
											}
											
											TaskChat.prototype.scrollToLastMessage = function(){
												if(this.chat.conversation.length > 0){
	  											  var el = 'statement_' + (this.chat.conversation.length -1)
	  											  document.getElementById(el).scrollIntoView();
												}
											  
											}
											
											TaskChat.prototype.getTaskChat = function(id){
												//console.log("ID: ", id)
												var that = this;
												
												this.chat = this.TasksService.taskChat[0];
												if(!this.chat.conversation){
													this.chat.conversation=[]
												}else{
													console.log(this.chat.conversation)
												}
												
												this.subscribe()
												var that = this;
												this.$timeout(function(){
												 	that.scrollToLastMessage()
												},200)
												
												 /*this.TasksService.getTaskChat(id).then(function(data){
													 if(!data.error && data.data.length >0 ){
														 that.chat =data.data[0];
														 that.chat.conversation=[]
														 console.log(data.data)
														 that.subscribe()
													 }
												 });*/
												
											}
											
											TaskChat.prototype.createMessage = function(){
												return {
															name:this.chat.user_name,
															userType:true,
															chat_id: this.chat.id,
															chat_title: this.chat.title,
															//chat_channel:this.chat.chat_channel,
															user_id:this.chat.user_id,
															user_client_id:this.chat.user_client_id,
															user_email:this.chat.user_email,
															message:this.newMessage
	
														}
											}
											
											TaskChat.prototype.publish = function() {
												var message  =  this.createMessage();
												var that = this;
												this.TasksService.insertMessage(message).then(function(){
														  that.PubNub.ngPublish({
														    channel: that.chat.chat_channel,
														    message: message
														  });
												},
												
												function(err){
													alert(err);													
												});
														  
											  this.newMessage='';	
											};
											
											TaskChat.prototype.subscribe = function() {
												var that = this;
												this.PubNub.ngSubscribe({
												      channel: this.chat.chat_channel,
												      callback: function(m) { 
														  console.log(m)
														  that.chat.conversation.push(m); 
														  that.$scope.$apply();
														  that.scrollToLastMessage();
													  }
												    })
													
											  this.$rootScope.$on(this.PubNub.ngMsgEv(this.chat.chat_channel), function(event, payload) {
											    // payload contains message, channel, env...
											    console.log('got a message event:', payload);
											  })
											  
											  this.$rootScope.$on(this.PubNub.ngPrsEv(this.chat.chat_channel), function(event, payload) {
											    // payload contains message, channel, env...
											    console.log('got a presence event:', payload);
											  })
											  
											  //this.PubNub.ngHistory({channel:this.chat.chat_channel, count:500});
										  }
											
											TaskChat.prototype.send = function(){}
											
											/*TaskChat.prototype.listen =	 function(){
												this.ChatFactory.listen(this.chat.chat_channel,function(m){console.log(m);})
											}*/
											
											
											
											return TaskChat;
			
							})()
		
	})(Genie.Controller || (Genie.Controller = {}) )
	
})(Genie || (Genie = {}));
genie.controller('TaskChatCtrl',['$scope','$timeout','$stateParams','TasksService','PubNub','$rootScope','PubNubCredentials', Genie.Controller.TaskChat]);