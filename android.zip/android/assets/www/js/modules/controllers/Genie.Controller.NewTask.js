var Genie;
(function(Genie){	
	
	(function(Controller){
		
		Controller.NewTask = (function(){
			
											function NewTask($scope, $ionicModal, $ionicPopup,$timeout, $state, TasksService,PubNub,PubNubCredentials){
												this.$scope 		= $scope;
												this.$ionicModal 	= $ionicModal;
												this.$timeout 		= $timeout;
												this.TasksService 	= TasksService;
												this.$ionicPopup 	= $ionicPopup;
												this.channels = PubNubCredentials.channels;
												this.$state = $state;
												this.PubNub = PubNub;
												this.PubNub.init({
														        publish_key: PubNubCredentials.publish_key,
														        subscribe_key: PubNubCredentials.subscribe_key,
																secret_key:PubNubCredentials.secret_key
														    });
												this.modal={};
											    // Form data for the login modal
											    this.newTaskData = {};
												var that = this;

											    // Create the login modal that we will use later
											    this.$ionicModal.fromTemplateUrl('templates/newtask.html', {
													 //NEED TO USE ANGULAR SCOPE....Object ASSOCIATED WITH POPERTY OF SCOPE
											      	scope:  this.$scope
											    }).then(function(modal) {													
											       	that.modal = modal;
											    });
												
												
												$scope.NewTask = this;
											};
											
											
											NewTask.prototype.addTask = function() {
														var that = this;
														
														if(!this.newTaskData.taskName){
															this.$ionicPopup.alert({
															     title: 'Alert',
															     template: 'Please Enter A Task Name.'
															   });
														}else{
															//console.log('Adding new task.',  this.newTaskData);
															  this.TasksService.addTask(this.newTaskData.taskName).then(function(data){
																  console.log(data.inserted)
																  if(data.inserted){
																	  that.newTaskData.taskName='';
						  												that.TasksService.getTasks().then(function(data){
																			  that.PubNub.ngPublish({
																				    channel: that.channels.newtasks,
																				    message: 'newtask'
																				  });
			    													         that.closeNewTask();
			    															 that.$state.go('tasks.current')
						  												});
		 													         
																  }else{
																	  alert("Error - " + data.error);
																	  
																  }
															  });
															  
													  		//console.log(this.TasksService.getTasks())
														}
												      
													 
													  
													  
											 };
												  
 											 NewTask.prototype.openNewTask = function() {
 											      this.modal.show();
 											 };
												
										     NewTask.prototype.closeNewTask = function() {
										      this.modal.hide();
										    };
												
											return NewTask;
									})();
									
								
	})(Genie.Controller || (Genie.Controller={}))


})(Genie || (Genie ={}))
genie.controller('NewTaskCtrl',['$scope', '$ionicModal', '$ionicPopup','$timeout','$state','TasksService','PubNub','PubNubCredentials', Genie.Controller.NewTask]);